* mywebsite folder is supposed to contain your web site
* widget is the widget module
* icon set by http://www.elegantthemes.com/blog/resources/free-social-media-icon-set